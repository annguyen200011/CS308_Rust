use crate::companies::Company::*;
use crate::employees::Employee::*;
use crate::values::credit;

pub enum Process{
    Starting,
    InProcess,
    Late,
    Finishing,
}

enum Status{
    Wait,
    InProcess,
    Done,
}

pub struct task {
    name: str,
    id: i32,
    owner: company,
    description: str,
    salary: f64,
    worker: employee,
    process: Process,
    status: Status,
    credit: credit,
}

trait Task{
    fn new(&self) -> Self;
    fn update_worker(&self);
    fn update_process(&self);
    fn update_status(&self);
    fn update_credit(&self);
    fn done_task(&self);
}

impl Task for task {
    fn new(&self) -> Self {
        todo!()
    }

    fn update_worker(&self) {
        todo!()
    }

    fn update_process(&self) {
        todo!()
    }

    fn update_status(&self) {
        todo!()
    }

    fn update_credit(&self) {
        todo!()
    }

    fn done_task(&self) {
        todo!()
    }
}





