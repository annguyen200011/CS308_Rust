mod companies;
mod employees;
mod jobs;
mod task;

use std::borrow::Borrow;
use task::*;
use companies::*;
use crate::company::Company;
use crate::company_type::CompanyType;
use crate::employee::Employee;
use crate::employee_level::EmployeeLevel;
use crate::employee_major::EmployeeMajor;
use crate::EmployeeLevel::*;
use crate::EmployeeMajor::*;
use crate::employees::*;
use crate::job::Job;
use crate::jobs::*;
use crate::recruitment::matching;
use crate::task_type::TaskType::*;
use crate::task_level::TaskLevel::*;

fn run_program1(){
    let mut coms = Companies::new();
    let mut com1 = Company::new_full(2, CompanyType::BigCompany, 500.0, Vec::new());

    com1.tasks.push(Task::new_full(32, Designing, Hard));
    com1.tasks.push(Task::new_full(7, Designing, Easy));
    com1.tasks.push(Task::new_full(11, Coding, Easy));
    com1.tasks.push(Task::new_full(31, Designing, Hard));
    com1.tasks.push(Task::new_full(54, Designing, Normal));
    com1.tasks.push(Task::new_full(41, Coding, Easy));
    com1.tasks.push(Task::new_full(52, Managing, Normal));
    com1.tasks.push(Task::new_full(12, Designing, Easy));
    com1.tasks.push(Task::new_full(14, Managing, Hard));
    com1.show_company();

    let mut com2 = Company::new_full(6, CompanyType::SmallCompany, 200.0, Vec::new());
    com2.tasks.push(Task::new_full(5, Managing, Easy));
    com2.tasks.push(Task::new_full(12, Designing, Hard));
    com2.tasks.push(Task::new_full(6, Managing, Normal));
    com2.tasks.push(Task::new_full(132, Designing, Normal));
    com2.tasks.push(Task::new_full(52, Managing, Easy));
    com2.tasks.push(Task::new_full(121, Designing, Hard));
    com2.tasks.push(Task::new_full(56, Managing, Easy));
    com2.tasks.push(Task::new_full(122, Designing, Easy));

    coms.add(com1);
    coms.add(com2);
    coms.show_companies();

    let mut employees = Employees::new();
    employees.add(Employee::new_full(32, Designer, Expert, 20.0));
    employees.add(Employee::new_full(100, Developer, Senior, 30.0));
    employees.add(Employee::new_full(302, Manager, Senior, 110.0));
    employees.add(Employee::new_full(11, Designer, Senior, 10.0));
    employees.add(Employee::new_full(323, Designer, Expert, 100.0));
    employees.add(Employee::new_full(105, Developer, Junior, 9.0));
    employees.add(Employee::new_full(322, Manager, Senior, 21.0));
    employees.add(Employee::new_full(294, Developer, Expert, 13.0));
    employees.show_employees();

    println!("Matching: ");
    for i in matching(coms, employees).iter(){
        println!("{:?} + {:?}", i.task, i.employee );
    }
}

fn main() {
    run_program1();

}
