use std::collections::HashMap;
use crate::employee;
use crate::tasks::Task::task;

pub struct company{
    name: str,
    id: i32,
    description: str,
    employees: vec![],
    current_tasks: vec![task],
    finished_tasks: vec![task],
    credit_score: i32,
    budget: f64,
}

trait Company{
    fn new(&self) -> Self;
    fn updateInfo(&self);
    fn newTask(&self) -> task;
    fn updateTask(&self);
    fn hiring(&self) -> employee;
    fn finishJob(&self);
}

impl Company for company{
    fn new(&self) -> Self{
        todo!()
    }

    fn updateInfo(&self) {
        todo!()
    }

    fn newTask(&self) -> task{
        todo!()
    }

    fn updateTask(&self){
        todo!()
    }

    fn hiring(&self) -> employee {
        todo!()
    }

    fn finishJob(&self){
        todo!()
    }
}
