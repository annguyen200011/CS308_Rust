use crate::{Employee, EmployeeLevel, EmployeeMajor};
use crate::employee_level::compare_level;
use crate::employee_major::compare_major;

pub mod employee {
    use crate::Job;
    use super::employee_major::*;
    use super::employee_level::*;

    #[derive(Debug, PartialEq)]
    pub enum EmployeeStatus {
        OnJob,
        FinJob,
        Free,
    }

    #[derive(Debug, PartialEq)]
    pub struct Employee {
        id: u32,
        _major: EmployeeMajor,
        _level: EmployeeLevel,
        exp: Box<Vec<Job>>,
        status: EmployeeStatus,
        job: Box<Option<Job>>,
        budget: f64,
        credit: u64,
    }

    impl Employee {
        pub fn new() -> Self {
            Self {
                id: 0,
                _major: EmployeeMajor::None,
                _level: EmployeeLevel::None,
                exp: Box::new(vec![]),
                status: EmployeeStatus::Free,
                job: Box::new(Option::None),
                budget: 0.0,
                credit: 0
            }
        }

        pub fn new_full(id: u32, _major: EmployeeMajor, _level: EmployeeLevel, budget: f64) -> Self {
            Self {
                id,
                _major,
                _level,
                exp: Box::new(vec![]),
                status: EmployeeStatus::Free,
                job: Box::new(Option::None),
                budget,
                credit: 0
            }
        }

        pub fn get_self(&self) -> Self{Self::new_full(self.get_id(), *self.get_major(), *self.get_level(), self.budget)}
        pub fn get_id(&self) -> u32{self.id}
        pub fn get_major(&self) -> &EmployeeMajor {&self._major}
        pub fn get_level(&self) -> &EmployeeLevel {&self._level}
        pub fn get_exp(&self) -> &Box<Vec<Job>> {&self.exp}
        pub fn get_status(&self) -> &EmployeeStatus {&self.status}
        pub fn get_job(&self) -> &Box<Option<Job>> {&self.job}
        pub fn get_credit(&self) -> u64{ self.credit }

        pub fn set_id(&mut self, id: u32) { self.id = id; }
        pub fn set_status(&mut self, status: EmployeeStatus) { self.status = status; }

        pub fn add_exp(&mut self, done_job: Job) { self.exp.push(done_job); }
        pub fn add_budget(&mut self, money: f64) { self.budget += money; }
        pub fn add_credit(&mut self, credit: u64) { self.credit += credit; }

        pub fn find_job(&mut self) { self.status = EmployeeStatus::FinJob; }

        pub fn accept_job(&mut self, new_job: Job) {
            self.status = EmployeeStatus::OnJob;
            self.job = Box::new(Some(new_job));
        }

        pub fn done_job(&mut self, job: Job) {
            self.status = EmployeeStatus::Free;
            self.job = Box::new(Option::None);
            self.budget += job.task.get_money();
            self.credit += job.task.get_credit();
            self.exp.push(job);
        }

        pub fn set_up(&mut self, _id: u32) {
            self.id = _id;
            self._major = get_major().unwrap();
            self._level = get_level().unwrap();
        }

        pub fn show_employee(&self) {
            println!("------Employee------");
            println!("| id: {}", self.id);
            println!("| major: {:?}", self._major);
            println!("| level: {:?}", self._level);
            println!("| exp: {:?}", self.exp);
            println!("| status: {:?}", self.status);
            println!("| job: {:?}", self.job);
            println!("| budget: {}", self.budget);
            println!("| credit: {}", self.credit);
            println!("--------------------");
            println!();
        }
    }
}

pub mod employee_level {
    use final_project::input::get_input;

    #[derive(Debug, PartialEq, Clone, Copy)]
    pub enum EmployeeLevel {
        Expert,
        Senior,
        Junior,
        None,
    }

    pub fn get_level() -> Result<EmployeeLevel, &'static str> {
        show_level();
        match get_input().as_deref() {
            Some("1") => Ok(EmployeeLevel::Expert),
            Some("2") => Ok(EmployeeLevel::Senior),
            Some("3") => Ok(EmployeeLevel::Junior),
            _ => Err("Please choose number from 1 to 3"),
        }
    }

    pub fn compare_level(level1: &EmployeeLevel, level2: &EmployeeLevel) -> bool{
        match (level1, level2) {
            (&EmployeeLevel::Expert, &EmployeeLevel::Expert) => true,
            (&EmployeeLevel::Senior, &EmployeeLevel::Senior) => true,
            (&EmployeeLevel::Junior, &EmployeeLevel::Junior) => true,
            _ => false
        }
    }

    fn show_level() {
        println!("--- Employee Level---");
        println!("Set your task number:");
        println!("---------------------");
        println!("| 1. Expert         |");
        println!("| 2. Senior         |");
        println!("| 3. Junior         |");
        println!("---------------------");
        println!();
    }
}

pub mod employee_major{
    use final_project::input::get_input;
    #[derive(Debug, PartialEq, Clone, Copy)]
    pub enum EmployeeMajor{
        Manager,
        Developer,
        Designer,
        None,
    }

    pub fn get_major() -> Result<EmployeeMajor,&'static str>{
        show_major();
        match get_input().as_deref(){
            Some("1") => Ok(EmployeeMajor::Manager),
            Some("2") => Ok(EmployeeMajor::Developer),
            Some("3") => Ok(EmployeeMajor::Designer),
            _ => Err("Please choose number from 1 to 3"),
        }
    }

    pub fn compare_major(major1: &EmployeeMajor, major2: &EmployeeMajor) -> bool{
        match (major1, major2) {
            (&EmployeeMajor::Manager, &EmployeeMajor::Manager) => true,
            (&EmployeeMajor::Developer, &EmployeeMajor::Developer) => true,
            (&EmployeeMajor::Designer, &EmployeeMajor::Designer) => true,
            _ => false
        }
    }


    fn show_major(){
        println!("--- Employee Major---");
        println!("Set your task number:");
        println!("---------------------");
        println!("| 1. Manager        |");
        println!("| 2. Developer      |");
        println!("| 3. Designer       |");
        println!("---------------------");
        println!();
    }


}

#[derive(Debug)]
pub struct Employees{
    employees: Box<Vec<Employee>>,
}

impl Employees{
    pub fn new()-> Self{
        Self{ employees: Box::new(vec![]) }
    }

    pub fn add(&mut self, employee: Employee){
        self.employees.push(employee);
    }

    pub fn sort_employees(&mut self){
        self.employees.sort_by(|a, b: &Employee| b.get_credit().cmp(&a.get_credit()))
    }

    fn employees_major_type_filter(&self, major: EmployeeMajor) -> Vec<&Employee>
    {
        let mut filter = Vec::new();
        for employee in self.employees.iter(){
            if compare_major(employee.get_major(), &major)
            {
                filter.push(employee);
            }
        }
        filter
    }

    fn employees_level_filter(&self, level: EmployeeLevel) -> Vec<&Employee>
    {
        let mut filter = Vec::new();
        for employee in self.employees.iter(){
            if compare_level(employee.get_level(), &level)
            {
                filter.push(employee);
            }
        }
        filter
    }

    pub fn employee_filter(&self, major: EmployeeMajor, level: EmployeeLevel) -> Vec<&Employee>{
        let mut filter = Vec::new();
        let major_filter = self.employees_major_type_filter(major);
        let level_filter = self.employees_level_filter(level);
        for employee in major_filter.iter(){
            if level_filter.contains(employee){
                filter.push(*employee);
            }
        }
        filter
    }


    pub fn show_employees(&self){
        println!("------------Employees------------");
        for employee in self.employees.iter(){
            println!("| Employee {}: {:?} {:?}, Status `{:?}, Experiences {:?}, Credit: {}", employee.get_id(), employee.get_level(),employee.get_major(),employee.get_status() ,employee.get_exp(), employee.get_credit());
        }
        println!("---------------------------------");
        println!();
    }
}


