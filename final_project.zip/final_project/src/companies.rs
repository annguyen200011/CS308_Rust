use crate::companies::company::Company;
use crate::Task;
use crate::task_level::TaskLevel;
use crate::task_type::TaskType;

pub mod company {
    use super::company_type::*;
    use crate::task::*;
    use std::borrow::Borrow;
    use crate::task_level::{compare_task_level, TaskLevel};
    use crate::task_type::{compare_type, TaskType};

    #[derive(Debug, Clone, PartialEq)]
    pub struct Company {
        id: u32,
        pub tasks: Vec<Task>,
        _type: CompanyType,
        budget: f64,
        credit: u64,
    }

    impl Company {
        pub fn new() -> Self {
            Self {
                id: 0,
                tasks: vec![],
                _type: CompanyType::None,
                budget: 0.0,
                credit: 0,
            }
        }

        pub fn new_full(id: u32, _type: CompanyType, budget: f64, tasks: Vec<Task>) -> Self {
            Self {
                id,
                tasks,
                _type,
                budget,
                credit: 0
            }
        }

        //pub fn get_self(&self) -> &Company {self}

        pub fn get_tasks(&self) -> &Vec<Task> { &self.tasks}

        pub fn get_id(&self) -> u32{self.id}

        pub fn get_type(&self) -> &CompanyType{self._type.borrow()}

        pub fn get_credit(&self) -> u64{
            self.credit
        }

        pub fn set_id(&mut self, id: u32) { self.id = id; }

        pub fn add_budget(&mut self, money: f64) { self.budget += money; }

        pub fn add_credit(&mut self, credit: u64) { self.credit += credit; }

        pub fn set_type(&mut self) { self._type = get_com_type().unwrap() }

        pub fn add_task(&mut self, id: u32) {
            let mut new_task = Task::new();
            new_task.set_up(id);
            let com_type = self._type.borrow();
            new_task.add_money(bonus_task_money(com_type, new_task));
            new_task.add_credit(bonus_task_credit(com_type, new_task));
            self.tasks.push(new_task);
        }

        pub fn _task_type_filter(&self, _type: TaskType) -> Vec<&Task>
        {
            let mut filter = Vec::new();
            for task in self.tasks.iter(){
                if compare_type(task.get_type(), &_type)
                {
                    filter.push(task);
                }
            }
            filter
        }

        pub fn _task_level_filter(&self, level: TaskLevel) -> Vec<&Task>
        {
            let mut filter = Vec::new();
            for task in self.tasks.iter(){
                if compare_task_level(task.get_level(), &level)
                {
                    filter.push(task);
                }
            }
            filter
        }

        pub fn company_filter(&self, _type: TaskType, level: TaskLevel) -> Vec<&Task>{
            let mut filter = Vec::new();
            let type_filter = self._task_type_filter(_type);
            let level_filter = self._task_level_filter(level);
            for employee in type_filter.iter(){
                if level_filter.contains(employee){
                    filter.push(*employee);
                }
            }
            filter
        }

        pub fn show_company(&self) {
            println!("------Company------");
            println!("| id: {}", self.id);
            println!("| tasks: {:?}", self.tasks);
            println!("| type: {:?}", self._type);
            println!("| budget: {:?}", self.budget);
            println!("| credit: {:?}", self.credit);
            println!("-------------------");
            println!();
        }


    }
}


pub mod company_type {
    use final_project::input::get_input;
    use crate::Task;

    #[derive(Debug, Clone, PartialEq)]
    pub enum CompanyType {
        BigCompany,
        SmallCompany,
        StartUp,
        None,
    }

    pub fn get_com_type() -> Result<CompanyType, &'static str> {
        show_com_type();
        match get_input().as_deref() {
            Some("1") => Ok(CompanyType::BigCompany),
            Some("2") => Ok(CompanyType::SmallCompany),
            Some("3") => Ok(CompanyType::StartUp),
            _ => Err("Please choose number from 1 to 3"),
        }
    }

    pub fn bonus_task_money(com_type: &CompanyType, task: Task) -> f64 {
        match com_type {
            CompanyType::BigCompany => task.get_money() * 0.5,
            CompanyType::SmallCompany => task.get_money() * 0.2,
            CompanyType::StartUp => task.get_money() * 0.05,
            _ => 0.0,
        }
    }

    pub fn bonus_task_credit(com_type: &CompanyType, task: Task) -> u64 {
        match com_type {
            CompanyType::BigCompany => (task.get_credit() as f64 * 0.3).round() as u64,
            CompanyType::SmallCompany => (task.get_credit() as f64 * 0.2).round() as u64,
            CompanyType::StartUp => (task.get_credit() as f64 * 0.1).round() as u64,
            _ => 0 as u64,
        }
    }

    fn show_com_type() {
        println!("-----Task Level-----");
        println!("Set your task number:");
        println!("---------------------");
        println!("| 1. Big Company    |");
        println!("| 2. Small Company  |");
        println!("| 3. Start Up       |");
        println!("---------------------");
        println!();
    }
}




pub struct Companies{
    companies: Box<Vec<Company>>,
}

impl Companies {
    pub fn new() -> Self{
        Self{
            companies: Box::new(vec![])
        }
    }

    pub fn add(&mut self, company: Company){
        self.companies.push(company);
    }

    pub fn get_companies(&self) -> &Box<Vec<Company>>{&self.companies}

    pub fn choose_index(&self, index: usize){
        self.companies[index].show_company()
    }

    pub fn sort_companies(&mut self){
        self.companies.sort_by(|a, b| b.get_credit().cmp(&a.get_credit()));
    }

    pub fn show_companies(&self){
        println!("------------Companies------------");
        for company in self.companies.iter(){
            println!("| Company {}: Type: {:?}, Credit: {}, Tasks: {:?}", company.get_id(),company.get_type(), company.get_credit(), company.get_tasks());
        }
        println!("---------------------------------");
        println!();
    }

    fn companies_task_type_filter(&self, _type: TaskType) -> Vec<&Task>
    {
        let mut filter = Vec::new();
        for company in self.companies.iter(){
            for task in company._task_type_filter(_type).iter(){
                filter.push(*task);
            }
        }
        filter
    }

    fn companies_task_level_filter(&self, level: TaskLevel) -> Vec<&Task>
    {
        let mut filter = Vec::new();
        for company in self.companies.iter(){
            for task in company._task_level_filter(level).iter(){
                filter.push(*task);
            }
        }
        filter
    }



}

