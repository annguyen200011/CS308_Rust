pub mod recruitment{
    use std::borrow::Borrow;
    use crate::employees::*;
    use crate::companies::*;
    use super::job::*;
    use std::collections::HashMap;
    use crate::{Employee, EmployeeLevel, EmployeeMajor};
    use crate::Task;
    use crate::task_level::TaskLevel;
    use crate::task_type::TaskType;


    fn matching_rule() -> (Vec<(&'static TaskLevel, Vec<&'static EmployeeLevel>)>, Vec<(&'static TaskType, Vec<&'static EmployeeMajor>)>)
    {
        let mut level_rule = Vec::new();
        level_rule.push((&TaskLevel::Hard, Vec::from([&EmployeeLevel::Expert])));
        level_rule.push((&TaskLevel::Normal, Vec::from([&EmployeeLevel::Senior, &EmployeeLevel::Junior])));
        level_rule.push((&TaskLevel::Easy, Vec::from([&EmployeeLevel::Junior])));

        let mut type_rule = Vec::new();
        type_rule.push((&TaskType::Managing, Vec::from([&EmployeeMajor::Manager])));
        type_rule.push((&TaskType::Designing, Vec::from([&EmployeeMajor::Designer])));
        type_rule.push((&TaskType::Coding, Vec::from([&EmployeeMajor::Developer])));

        (level_rule, type_rule)
    }



    pub fn matching(mut cops: Companies,mut ems: Employees) -> Vec<Job>{
        cops.sort_companies();
        ems.sort_employees();

        let mut jobs: Vec<Job> = Vec::new();
        let type_rule = matching_rule().1;
        let level_rule = matching_rule().0;


        for _type in type_rule.iter(){
            let task_type = _type.0;

            for &&employee_major in _type.1.iter(){
                for level in level_rule.iter(){
                    let task_level = level.0;

                    for &&employee_level in level.1.iter(){

                        let filter_employee = ems.employee_filter(employee_major, employee_level);
                        for company in cops.get_companies().iter(){
                            let filter_tasks = company.company_filter(*task_type, *task_level);

                            if filter_tasks.len() == 0 || filter_employee.len() == 0{break}
                            else if filter_tasks.len() > filter_employee.len(){
                                for i in 0..filter_employee.len(){
                                    let mut new_job = Job::new();
                                    new_job.set_task(filter_tasks[i]);
                                    new_job.set_company(company);
                                    new_job.employee = filter_employee[i].get_self();
                                    jobs.push(new_job);
                                }
                            }
                            else {
                                for j in 0..filter_tasks.len() {
                                    let mut new_job = Job::new();
                                    new_job.set_task(filter_tasks[j]);
                                    new_job.set_company(company);
                                    new_job.employee = filter_employee[j].get_self();
                                    jobs.push(new_job);
                                }
                            }
                        }
                    }
                }
            }
        }
        jobs

    }





}

pub mod job{
    use std::borrow::Borrow;
    use crate::{Employees, Task};
    use crate::companies::company::*;
    use crate::employees::employee::*;

    #[derive(Debug, PartialEq)]
    enum JobProcess{
        Starting,
        Quarter,
        Haft,
        ThreeFourths,
        Finishing,
        Done,
    }


    #[derive(Debug, PartialEq)]

    pub struct Job{
        pub task: Task,
        pub company: Company,
        pub employee: Employee,
        process: JobProcess,
        deadline: u64,
    }

    impl Job {
        pub fn new() -> Self{
            Self{
                task: Task::new(),
                company: Company::new(),
                employee: Employee::new(),
                process: JobProcess::Starting,
                deadline: 0
            }
        }
        pub fn new_ful(task: &Task, company: Company, employee: Employee, deadline: u64) -> Self{
            Self{
                task: *task,
                company: company,
                employee: employee,
                process: JobProcess::Starting,
                deadline,
            }
        }

        pub fn get_task(&self) -> Task{self.task}

        pub fn set_task(&mut self, task : &Task) {self.task = *task}

        pub fn get_company(&self) -> Company{self.get_company()}

        pub fn set_company(&mut self, company : &Company) {self.company = company.clone()}

        pub fn get_employee(&self) -> Employee{self.get_employee()}

        pub fn set_employee(&mut self, employee : Employee) {self.employee = employee}

        pub fn update_process(&mut self, process: JobProcess){self.process = process;}

        pub fn get_process(&self) -> &JobProcess{self.process.borrow()}

        pub fn set_deadline(&mut self, time: u64) {self.deadline = time;}

        pub fn get_deadline(&self) -> u64 {self.deadline}

        pub fn certificate(&mut self, job: Job) { self.employee.done_job(job); }

        pub fn show_job(&self){
            println!("------Job------");
            println!("| task: {:?}", self.task);
            println!("| company: {:?}", self.company);
            println!("| employee: {:?}", self.employee);
            println!("| process: {:?}", self.process);
            println!("| deadline: {:?}", self.deadline);
            println!("--------------");
            println!();
        }
    }

}

pub mod jobs{
    use crate::Job;

    struct Jobs{
        jobs: Vec<Job>,
    }
}

pub mod certificate{
    struct Certificate{

    }
}

