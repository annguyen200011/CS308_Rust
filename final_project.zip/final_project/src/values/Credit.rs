use crate::companies::Company::company;
use crate::employees::Employee::employee;

enum Level{
    Low,
    Medium,
    High,
}

pub struct credit{
    score: i32,
    history: (T,i32),
    company: company,
    employee: employee,
    level: Level,
}

trait Calculate{
    fn add(&self) -> Self;
    fn subtract(&self) -> Self;
}

impl Calculate for credit{
    fn add(&self) -> Self {
        todo!()
    }

    fn subtract(&self) -> Self {
        todo!()
    }
}

fn calculate(level: Level) -> i32 {
    0
}


