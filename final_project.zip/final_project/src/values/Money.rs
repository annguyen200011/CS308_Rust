use crate::companies::Company::company;
use crate::employees::Employee::employee;
use crate::tasks::Task::*;

pub struct money{
    owner_id: i32,
    value: f64,
    history: Box<vec![(company,employee)]>,
}

trait Contract {
    fn new(&self) -> Self;
    fn error(&self) -> Option<bool>;
    fn add(&self);
    fn remove(&self);
}

impl Contract for money {
    fn new(&self) -> Self {
        todo!()
    }

    fn error(&self) -> Option<bool> {
        todo!()
    }

    fn add(&self) {
        todo!()
    }

    fn remove(&self) {
        todo!()
    }
}
