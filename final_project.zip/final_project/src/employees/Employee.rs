use crate::tasks::Task::*;
use crate::company;
use crate::lib;


pub enum Status{
    Free,
    Working,
}

pub struct employee{
    name: str,
    age: i8,
    id: i32,
    exp: str,
    certificate: vec![],
    status: Status,
    task_process: Process,
}

trait Employee{
    fn new(&self) -> Self;
    fn update(&self);
    fn findJob(&self) -> task;
    fn acceptJob(&self) -> bool;
    fn finishJob(&self) -> bool;
}

impl Employee for employee{
    fn new(&self) -> Self {
        todo!()
    }

    fn update(&self){
        todo!()
    }

    fn findJob(&self) -> (Self, task) {
        todo!()
    }

    fn acceptJob(&self) -> bool {
        todo!()
    }

    fn finishJob(&self) -> bool {
        todo!()
    }
}
