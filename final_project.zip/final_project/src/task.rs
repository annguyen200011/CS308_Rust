use std::borrow::Borrow;
use final_project::input::get_input;
use crate::task::task_level::*;
use crate::task::task_type::*;

pub mod task_level{
    use final_project::input::get_input;
    use std::collections::HashMap;

    #[derive(Debug, Clone, Copy, Eq, PartialEq)]
    pub enum TaskLevel{
        Hard,
        Normal,
        Easy,
        None,
    }

    pub fn get_level() -> Result<TaskLevel,&'static str>{
        show_level();
        match get_input().as_deref(){
            Some("1") => Ok(TaskLevel::Hard),
            Some("2") => Ok(TaskLevel::Normal),
            Some("3") => Ok(TaskLevel::Easy),
            _ => Err("Please choose number from 1 to 3"),
        }
    }

    pub fn get_task_level_money(level: TaskLevel) -> f64{
        match level {
            TaskLevel::Hard => 20.0,
            TaskLevel::Normal => 15.0,
            TaskLevel::Easy => 10.0,
            _ => 0.0,
        }
    }

    pub fn get_task_level_credit(level: TaskLevel) -> u64 {
        match level {
            TaskLevel::Hard => 7,
            TaskLevel::Normal => 4,
            TaskLevel::Easy => 2,
            _ => 0,
        }
    }

    pub fn compare_task_level(level1: &TaskLevel, level2: &TaskLevel) -> bool{
        match (level1, level2) {
            (&TaskLevel::Hard, &TaskLevel::Hard) => true,
            (&TaskLevel::Normal, &TaskLevel::Normal) => true,
            (&TaskLevel::Easy, &TaskLevel::Easy) => true,
            _ => false
        }
    }

    fn show_level(){
        println!("-----Task Level-----");
        println!("Set your task number:");
        println!("---------------------");
        println!("| 1. Hard           |");
        println!("| 2. Normal         |");
        println!("| 3. Easy           |");
        println!("---------------------");
        println!();
    }

}

pub mod task_type {
    use final_project::input::{get_input, get_int};

    #[derive(Debug, Clone, Copy,PartialEq, PartialOrd)]
    pub enum TaskType {
        Managing,
        Coding,
        Designing,
        None,
    }

    pub fn get_type() -> Result<TaskType, &'static str> {
        show_type();
        match get_input().as_deref() {
            Some("1") => Ok(TaskType::Managing),
            Some("2") => Ok(TaskType::Coding),
            Some("3") => Ok(TaskType::Designing),
            _ => Err("Please choose number from 1 to 3!"),
        }
    }

    pub fn get_task_type_money(_type: TaskType) -> f64 {
        match _type {
            TaskType::Managing => 20.0,
            TaskType::Coding => 15.0,
            TaskType::Designing => 10.0,
            _ => 0.0,
        }
    }

    pub fn get_task_type_credit(_type: TaskType) -> u64 {
        match _type {
            TaskType::Managing => 10,
            TaskType::Coding => 5,
            TaskType::Designing => 4,
            _ => 0,
        }
    }

    pub fn compare_type(type1: &TaskType, type2: &TaskType) -> bool{
        match (type1, type2) {
            (&TaskType::Managing, &TaskType::Managing) => true,
            (&TaskType::Designing, &TaskType::Designing) => true,
            (&TaskType::Coding, &TaskType::Coding) => true,
            _ => false
        }
    }


    fn show_type() {
        println!("-----Task Level-----");
        println!("Set your task number:");
        println!("---------------------");
        println!("| 1. Managing       |");
        println!("| 2. Coding         |");
        println!("| 3. Designing      |");
        println!("---------------------");
        println!();
    }
}
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Task {
    id: u32,
    _type: task_type::TaskType,
    _level: task_level::TaskLevel,
    money: f64,
    credit: u64,
}

impl Task {
    pub fn new() -> Self{
        Self{
            id: 0,
            _type: TaskType::None,
            _level: TaskLevel::None,
            money: 0.0,
            credit: 0
        }
    }

    pub fn new_full( id: u32, _type: TaskType, _level: TaskLevel) -> Self{
        let mut new_task = Task::new();
        new_task.id = id;
        new_task._type = _type;
        new_task._level = _level;
        new_task.money = new_task.set_money(_type, _level);
        new_task.credit = new_task.set_credit(_type,_level);
        new_task
    }

    pub fn get_self(&self) -> &Task {self}

    pub fn get_id(&self) -> &u32 {&self.id}

    pub fn get_money(&self) -> f64 {self.money}

    pub fn get_credit(&self) -> u64 {self.credit}

    pub fn get_type(&self) -> &TaskType { self._type.borrow() }

    pub fn get_level(&self) -> &TaskLevel {self._level.borrow()}

    pub fn add_money(&mut self, money: f64){self.money= self.money + money}

    pub fn add_credit(&mut self, credit: u64){self.credit= self.credit + credit}

    fn set_money(&self, task_type: TaskType, task_level: TaskLevel) -> f64{
        get_task_type_money(task_type) * get_task_level_money(task_level)
    }

    fn set_credit(&self, task_type: TaskType, task_level: TaskLevel) -> u64{
        get_task_type_credit(task_type) * get_task_level_credit(task_level)
    }

    pub fn set_up(&mut self, id: u32){
        let task_type =  get_type().unwrap();
        self._type = task_type;
        let mut task_level = get_level().unwrap();
        self._level = task_level;
        self.id = id;
        self.money = self.set_money(task_type, task_level);
        self.credit = self.set_credit(task_type,task_level);
    }

    pub fn show_task(&self){
        println!("------Task------");
        println!("| id: {}", self.id);
        println!("| type: {:?}", self.get_type());
        println!("| level: {:?}", self.get_level());
        println!("| money: {}", self.money);
        println!("| credit: {}", self.credit);
        println!("----------------");
        println!();
    }
}

